public interface PrzykladowyInterface {

    void sayHelloWorld();

    Double returnRandomNumber();
}
