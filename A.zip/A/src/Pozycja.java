public class Pozycja {
    String nazwaTowaru;
    int ileSztuk;
    double cena;

    double cena_koncowa;

    public Pozycja(String nazwaTowaru, int ileSztuk, double cena) {
        this.nazwaTowaru = nazwaTowaru;
        this.ileSztuk = ileSztuk;
        this.cena = cena;
    }

    public String getNazwaTowaru() {
        return nazwaTowaru;
    }

    public void setNazwaTowaru(String nazwaTowaru) {
        this.nazwaTowaru = nazwaTowaru;
    }

    public int getIleSztuk() {
        return ileSztuk;
    }

    public void setIleSztuk(int ileSztuk) {
        this.ileSztuk = ileSztuk;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

public double obliczWartosc(){
        cena_koncowa = ileSztuk*cena;
        return cena_koncowa;
}

    public double getCena_koncowa() {
        return cena_koncowa;
    }

    public void setCena_koncowa(double cena_koncowa) {
        this.cena_koncowa = cena_koncowa;
    }

    @Override
    public String toString() {
        return "Pozycja{" +
                "nazwaTowaru='" + nazwaTowaru + '\'' +
                ", ileSztuk=" + cena +
                ", cena=" + ileSztuk +
                ", cena=" + obliczWartosc() +
                '}';
    }
}
