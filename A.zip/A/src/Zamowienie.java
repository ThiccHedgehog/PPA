import java.util.ArrayList;
import java.util.List;

public class Zamowienie {

    int ileDodanych;
    int maksRozmiar;


    public Zamowienie(){
       maksRozmiar = 10;
    }
    public Zamowienie(int maksRozmiar){

    }

    public void dodajPozycje(Pozycja p){

    }
    Pozycja[] pozycje = new Pozycja[maksRozmiar];

}
