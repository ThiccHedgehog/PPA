package Dziedziczenie;

public class Jacht extends Pojazd{
    public Jacht(String marka, String model) {
        super(marka, model);
    }
}
